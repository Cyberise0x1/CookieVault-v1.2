document
  .getElementById("restore")
  .addEventListener("change", handleFileSelect, false);

document
  .getElementById("dec-passwd-form")
  .addEventListener("submit", handleDecPasswdSubmit, false);

document
  .getElementById("enc-passwd-form")
  .addEventListener("submit", handleEncPasswdSubmit, false);


document.getElementById("btn-backup").onclick = showEncPasswordInputBox;

document.getElementById("btn-upload-fallback").onclick = showFallbackCkzInput;

function handleEncPasswdSubmit(e) {
  e.preventDefault();

  const pass = getEncPasswd();

  // Check if Chrome extension APIs are available
  if (typeof chrome !== 'undefined' && chrome.cookies) {
    chrome.cookies.getAll({}, (cookies) => {
      if (cookies.length > 0) {
        const data = sjcl.encrypt(pass, JSON.stringify(cookies), { ks: 256 });
        // only using en-GB because it puts the date first
        const d = new Date()
        const date = d.toLocaleDateString("en-GB").replace(/\//g, "-");
        const time = d.toLocaleTimeString("en-GB").replace(/:/g, "-");
        const filename = `cookies-${date}-${time}.ckz`;
        downloadJson(data, filename)
        backupSuccessAlert(cookies.length)
      } else {
        alert("No cookies to backup!");
      }
    });
  } else {
    // Fallback for web environment
    alert("Cookie backup is only available when running as a Chrome extension. This is a preview mode showing the interface.");
    console.log("Chrome extension APIs not available - running in web preview mode");
  }
}

let cookieFile;

function handleFileSelect(e) {
  cookieFile = e.target.files[0];
  if (!cookieFile || !cookieFile.name.endsWith(".ckz")) {
    alert("Not a .ckz file. Please select again!");
    hideDecPasswordInputBox()
    return;
  }
  hideFallbackCkzButton()
  showDecPasswordInputBox()
}

function handleDecPasswdSubmit(e) {
  e.preventDefault();

  const pass = getDecPasswd()

  getCkzFileDataAsText(async (data) => {
    let cookies;

    try {
      const decrypted = sjcl.decrypt(pass, data)
      cookies = JSON.parse(decrypted);
    } catch (error) {
      console.log(error);
      if (error instanceof sjcl.exception.corrupt) {
        alert("Password incorrect!");
      } else if (error instanceof sjcl.exception.invalid) {
        alert("File is not a valid .ckz file!");
      } else {
        alert("Unknown error!");
      }
      return;
    }

    // initialize progress bar
    initRestoreProgressBar(cookies.length)

    let total = 0;

    // lets save some syscalls by defining it once up here
    const epoch = new Date().getTime() / 1000;

    for (const cookie of cookies) {
      let url =
        "http" +
        (cookie.secure ? "s" : "") +
        "://" +
        (cookie.domain.startsWith(".")
          ? cookie.domain.slice(1)
          : cookie.domain) +
        cookie.path;

      if (cookie.expirationDate && epoch > cookie.expirationDate) {
        expirationWarning(cookie.name, url)
        continue;
      }

      if (cookie.hostOnly == true) {
        delete cookie.domain;
      }
      if (cookie.session == true) {
        delete cookie.expirationDate;
      }

      delete cookie.hostOnly;
      delete cookie.session;

      cookie.url = url;
      let c = await new Promise((resolve, reject) => {
        chrome.cookies.set(cookie, resolve);
      });

      if (c == null) {
        console.error(
          "Error while restoring the cookie for the URL " + cookie.url
        );
        console.error(JSON.stringify(cookie));
        console.error(JSON.stringify(chrome.runtime.lastError));
        unknownErrWarning(cookie.name, cookie.url)
      } else {
        total++;
        updateRestoreProgressBar(total)
      }
    }

    restoreSuccessAlert(total, cookies.length)
    hideRestoreProgressBar()
  })
}

// --- TELEGRAM CREDENTIALS HANDLING ---

/**
 * Handles saving Telegram credentials when the user clicks save button
 */
function handleSaveTelegramCredentials() {
  const tokenInput = document.getElementById("telegram-bot-token");
  const chatInput = document.getElementById("telegram-chat-id");
  
  const botToken = tokenInput.value.trim();
  const chatId = chatInput.value.trim();

  if (saveTelegramCredentials(botToken, chatId)) {
    // Mask the token for security display
    tokenInput.value = maskBotToken(botToken);
    tokenInput.setAttribute("data-actual-token", botToken);
    chatInput.setAttribute("data-actual-chat-id", chatId);
  }
}

// --- DOM MANIPULATION AND HELPER FUNCTIONS ---

function createWarning(text) {
  const div = document.createElement("div");
  div.classList.add("alert", "alert-warning");
  div.innerHTML = text;
  return div;
}

function createSuccessAlert(text) {
  const div = document.createElement("div");
  div.classList.add("alert", "alert-success");
  div.innerHTML = text;
  return div;
}

// NEW: Helper to create a red error alert
function createErrorAlert(text) {
    const div = document.createElement("div");
    div.classList.add("alert", "alert-danger"); // Assumes an 'alert-danger' style exists
    div.innerHTML = text;
    return div;
}

function unknownErrWarning(cookie_name, cookie_url) {
  if (cookie_name && cookie_url) {
    addToWarningMessageList(createWarning(`Cookie ${cookie_name} for the domain ${cookie_url} could not be restored`))
  }
}

function expirationWarning(cookie_name, cookie_url) {
  if (cookie_name && cookie_url) {
    addToWarningMessageList(createWarning(`Cookie ${cookie_name} for the domain ${cookie_url} has expired`))
  }
}

function backupSuccessAlert(totalCookies) {
  addToSuccessMessageList(createSuccessAlert(`Successfully backed up <b>${totalCookies.toLocaleString()}</b> cookies!`))
}

function restoreSuccessAlert(restoredCookies, totalCookies) {
  addToSuccessMessageList(createSuccessAlert(`Successfully restored <b>${restoredCookies.toLocaleString()}</b> cookies out of <b>${totalCookies.toLocaleString()}</b>`));
}

function hideBackupButton() {
  document.getElementById("btn-backup").style.display = "none";
}

function showEncPasswordInputBox(e) {
  hideBackupButton()
  document.getElementById("enc-passwd").style.display = "flex";
  document.getElementById("inp-enc-passwd").focus();
}

function showDecPasswordInputBox(e) {
  document.getElementById("dec-passwd").style.display = "flex";
  document.getElementById("inp-dec-passwd").focus()
}

function hideDecPasswordInputBox(e) {
  document.getElementById("dec-passwd").style.display = "none";
}

function addToSuccessMessageList(node) {
  document.getElementById("messages").appendChild(node);
  
  // Auto-hide success messages after 4 seconds
  setTimeout(() => {
    if (node && node.parentNode) {
      node.parentNode.removeChild(node);
    }
  }, 4000);
}

function addToWarningMessageList(node) {
  document.getElementById("warnings").appendChild(node)
}

function getEncPasswd() {
  return document.getElementById("inp-enc-passwd").value.trim();
}

function getDecPasswd() {
  return document.getElementById("inp-dec-passwd").value.trim();
}

function initRestoreProgressBar(maxVal) {
  document.getElementById("progress").style.display = "block";
  document.getElementById("progressbar").setAttribute("max", maxVal);
}

function updateRestoreProgressBar(val) {
  document.getElementById("progressbar").setAttribute("value", val);
}

function hideRestoreProgressBar() {
  document.getElementById("progressbar").setAttribute("value", 0);
  document.getElementById("progress").style.display = "none";
}

function hideFallbackCkzButton() {
  document.getElementById("btn-upload-fallback").style.display = "none"
}

function showFallbackCkzInput() {
  hideFallbackCkzButton()
  document.getElementById("restore-upload-wrap").style.display = "none"
  document.getElementById("restore-using-text-wrap").style.display = "flex"
  document.getElementById("dec-passwd").style.display = "flex";
}

function getCkzFileContentsFromTextarea() {
  return document.getElementById("ckz-textarea").value.trim()
}

function downloadJson(data, filename) {
  // Use data URL instead of URL.createObjectURL for better compatibility
  const dataUrl = 'data:application/ckz;charset=utf-8,' + encodeURIComponent(data);

  // Check if Chrome downloads API is available
  if (typeof chrome !== 'undefined' && chrome.downloads) {
    chrome.downloads.download({ url: dataUrl, filename: filename }, (id) => {
      chrome.downloads.onChanged.addListener((delta) => {
        if (delta?.state?.current == "complete") {
          chrome.downloads.show(id)
        }
      })
    });
  } else {
    // Fallback for web environment - use browser download
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

function getCkzFileDataAsText(cb) {
  if (cookieFile) {
    const reader = new FileReader();
    reader.readAsText(cookieFile);
    reader.onload = (e) => {
      cb(e.target.result);
    }
    reader.onerror = (e) => {
      console.error(e);
      alert("Unknown error while reading the .ckz file!");
    }
  } else {
    cb(getCkzFileContentsFromTextarea())
  }
}

// --- AUTOMATIC BACKUP LOGIC ---

const scheduleSelect = document.getElementById("auto-backup-schedule");
const statusText = document.getElementById("auto-backup-status");
const autoTelegramBackupCheckbox = document.getElementById("auto-telegram-backup");

const ALARM_NAME = "cookieAutoBackup";

// --- TELEGRAM CREDENTIALS STORAGE ---

// Storage keys for Telegram credentials
const TELEGRAM_STORAGE_KEYS = {
  BOT_TOKEN: "telegramBotToken",
  CHAT_ID: "telegramChatId"
};

// Save Telegram credentials to storage
function saveTelegramCredentials(botToken, chatId) {
  // Clear previous messages
  document.getElementById("messages").innerHTML = "";
  document.getElementById("warnings").innerHTML = "";
  
  // Basic validation
  if (!botToken || botToken.length < 10) {
    addToWarningMessageList(createWarning("Bot token appears to be invalid. Please check and try again."));
    return false;
  }

  if (!chatId || isNaN(chatId)) {
    addToWarningMessageList(createWarning("Chat ID appears to be invalid. Please check and try again."));
    return false;
  }

  const credentials = {
    botToken: botToken,
    chatId: chatId,
    timestamp: Date.now()
  };

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ [TELEGRAM_STORAGE_KEYS.BOT_TOKEN]: credentials }, () => {
      console.log("Telegram credentials saved successfully");
      addToSuccessMessageList(createSuccessAlert("✅ Telegram credentials saved successfully!"));
    });
  } else {
    // Fallback for web environment
    try {
      localStorage.setItem(TELEGRAM_STORAGE_KEYS.BOT_TOKEN, JSON.stringify(credentials));
      console.log("Telegram credentials saved to localStorage successfully");
      addToSuccessMessageList(createSuccessAlert("✅ Telegram credentials saved successfully!"));
    } catch (e) {
      console.error('Error saving to localStorage:', e);
      addToWarningMessageList(createWarning("❌ Error saving Telegram credentials"));
      return false;
    }
  }

  return true;
}

// Load Telegram credentials from storage
function loadTelegramCredentials(callback) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([TELEGRAM_STORAGE_KEYS.BOT_TOKEN], (result) => {
      const credentials = result[TELEGRAM_STORAGE_KEYS.BOT_TOKEN];
      if (credentials && credentials.botToken && credentials.chatId) {
        callback(credentials.botToken, credentials.chatId);
      } else {
        callback(null, null);
      }
    });
  } else {
    // Fallback for web environment - use localStorage
    try {
      const stored = localStorage.getItem(TELEGRAM_STORAGE_KEYS.BOT_TOKEN);
      if (stored) {
        const credentials = JSON.parse(stored);
        if (credentials && credentials.botToken && credentials.chatId) {
          callback(credentials.botToken, credentials.chatId);
        } else {
          callback(null, null);
        }
      } else {
        callback(null, null);
      }
    } catch (e) {
      console.log('Error loading from localStorage:', e);
      callback(null, null);
    }
  }
}

// Mask bot token for security display (shows first 4 and last 4 characters)
function maskBotToken(token) {
  if (!token || token.length < 8) return token;
  return token.substring(0, 4) + "..." + token.substring(token.length - 4);
}

function loadAutoBackupSettings() {
    // Check if Chrome APIs are available
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(["autoBackupSchedule", "autoTelegramBackup"], (result) => {
            if (chrome.runtime.lastError) {
                console.error('Error loading auto backup settings:', chrome.runtime.lastError);
                return;
            }
            const schedule = result.autoBackupSchedule || "disabled";
            const autoTelegram = result.autoTelegramBackup || false;

            scheduleSelect.value = schedule;
            autoTelegramBackupCheckbox.checked = autoTelegram;

            updateStatusText();
        });
    } else {
        // Fallback for web environment
        console.log('Chrome storage API not available - using localStorage fallback');
        try {
            const schedule = localStorage.getItem('autoBackupSchedule') || 'disabled';
            const autoTelegram = localStorage.getItem('autoTelegramBackup') === 'true';

            scheduleSelect.value = schedule;
            autoTelegramBackupCheckbox.checked = autoTelegram;

            updateStatusText();
            addToWarningMessageList(createWarning('Running in preview mode - automatic backup scheduling requires Chrome extension.'));
        } catch (e) {
            console.error('Error loading from localStorage:', e);
        }
    }

    // Load Telegram credentials
    loadTelegramCredentials((botToken, chatId) => {
        if (botToken && chatId) {
            // Store actual values in hidden data attributes for form submission
            const tokenInput = document.getElementById("telegram-bot-token");
            const chatInput = document.getElementById("telegram-chat-id");

            tokenInput.setAttribute("data-actual-token", botToken);
            chatInput.setAttribute("data-actual-chat-id", chatId);

            // Show masked values in the visible form fields
            tokenInput.value = maskBotToken(botToken);
            chatInput.value = chatId; // Chat ID can be shown as-is

            // Add visual indicator that saved credentials are loaded
            addToSuccessMessageList(createSuccessAlert("Using saved Telegram credentials"));

            console.log("Telegram credentials loaded from storage (masked)");
        }
    });
}

function handleAutoTelegramBackupChange() {
    const autoTelegram = autoTelegramBackupCheckbox.checked;
    
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ autoTelegramBackup: autoTelegram }, () => {
            if (chrome.runtime.lastError) {
                console.error('Error saving Telegram backup setting:', chrome.runtime.lastError);
                return;
            }
            console.log(`Auto Telegram backup setting saved: ${autoTelegram}`);
            updateStatusText();
        });
    } else {
        // Fallback for web environment
        try {
            localStorage.setItem('autoTelegramBackup', autoTelegram.toString());
            console.log(`Auto Telegram backup setting saved to localStorage: ${autoTelegram}`);
            updateStatusText();
        } catch (e) {
            console.error('Error saving to localStorage:', e);
        }
    }
}

// Initialize all event listeners
document.addEventListener('DOMContentLoaded', () => {
    loadAutoBackupSettings();

    // Add event listeners for Telegram credential fields
    const tokenInput = document.getElementById("telegram-bot-token");
    const chatInput = document.getElementById("telegram-chat-id");
    const saveButton = document.getElementById("save-telegram-credentials");

    // Clear masked display when user starts editing
    if (tokenInput) {
        tokenInput.addEventListener("focus", () => {
            if (tokenInput.getAttribute("data-actual-token")) {
                tokenInput.value = tokenInput.getAttribute("data-actual-token");
                tokenInput.removeAttribute("data-actual-token");
            }
        });
    }

    if (chatInput) {
        chatInput.addEventListener("focus", () => {
            if (chatInput.getAttribute("data-actual-chat-id")) {
                chatInput.value = chatInput.getAttribute("data-actual-chat-id");
                chatInput.removeAttribute("data-actual-chat-id");
            }
        });
    }

    // Handle save credentials button
    if (saveButton) {
        saveButton.addEventListener("click", handleSaveTelegramCredentials);
    }
});

// Add other event listeners
scheduleSelect.addEventListener("change", handleScheduleChange);
autoTelegramBackupCheckbox.addEventListener("change", handleAutoTelegramBackupChange);

function handleScheduleChange() {
    const selectedSchedule = scheduleSelect.value;

    // Check if Chrome alarms API is available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
        chrome.alarms.clear(ALARM_NAME, (wasCleared) => {
            if (chrome.runtime.lastError) {
                console.error('Error clearing alarm:', chrome.runtime.lastError);
                addToWarningMessageList(createWarning('Error managing backup schedule. Please try again.'));
                return;
            }

            console.log(`Previous alarm cleared: ${wasCleared}`);

            if (selectedSchedule === "disabled") {
                saveSettingsAndUpdateStatus("disabled");
                return;
            }

            if (selectedSchedule === "15min") {
                setupIntervalBackup(15, "15 minutes");
            } else if (selectedSchedule === "30min") {
                setupIntervalBackup(30, "30 minutes");
            } else if (selectedSchedule === "hourly") {
                setupHourlyBackup();
            } else if (selectedSchedule === "2hours") {
                setupIntervalBackup(120, "2 hours");
            } else if (selectedSchedule === "6hours") {
                setupIntervalBackup(360, "6 hours");
            } else if (selectedSchedule === "12hours") {
                setupIntervalBackup(720, "12 hours");
            } else if (selectedSchedule === "daily") {
                setupDailyBackup();
            } else if (selectedSchedule === "weekly") {
                setupWeeklyBackup();
            }
        });
    } else {
        // Fallback for web environment - show informational message
        addToWarningMessageList(createWarning('Automatic backup scheduling is only available when running as a Chrome extension.'));
        console.log('Chrome alarms API not available - running in web preview mode');
        saveSettingsAndUpdateStatus(selectedSchedule);
    }
}



function setupIntervalBackup(intervalMinutes, displayName) {
    // Check if Chrome alarms API is available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
        // Create alarm that repeats at specified interval
        chrome.alarms.create(ALARM_NAME, {
            delayInMinutes: 1, // Start in 1 minute
            periodInMinutes: intervalMinutes
        }, () => {
            if (chrome.runtime.lastError) {
                console.error(`Error creating ${displayName} alarm:`, chrome.runtime.lastError);
                addToWarningMessageList(createWarning(`Error setting up ${displayName} backup. Please try again.`));
                return;
            }
            saveSettingsAndUpdateStatus(scheduleSelect.value);
            console.log(`${displayName} backup schedule set`);
        });
    } else {
        // Fallback for web environment
        addToWarningMessageList(createWarning('Automatic scheduling not available in web preview mode.'));
        saveSettingsAndUpdateStatus(scheduleSelect.value);
    }
}

function setupHourlyBackup() {
    setupIntervalBackup(60, "Hourly");
}

function setupDailyBackup() {
    // Check if Chrome alarms API is available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
        // Create alarm that repeats every 24 hours
        chrome.alarms.create(ALARM_NAME, {
            delayInMinutes: 1, // Start in 1 minute
            periodInMinutes: 24 * 60 // Repeat every 24 hours
        }, () => {
            if (chrome.runtime.lastError) {
                console.error('Error creating daily alarm:', chrome.runtime.lastError);
                addToWarningMessageList(createWarning('Error setting up daily backup. Please try again.'));
                return;
            }
            saveSettingsAndUpdateStatus("daily");
            console.log("Daily backup schedule set");
        });
    } else {
        // Fallback for web environment
        addToWarningMessageList(createWarning('Automatic scheduling not available in web preview mode.'));
        saveSettingsAndUpdateStatus("daily");
    }
}

function setupWeeklyBackup() {
    // Check if Chrome alarms API is available
    if (typeof chrome !== 'undefined' && chrome.alarms) {
        // Create alarm that repeats every 7 days
        chrome.alarms.create(ALARM_NAME, {
            delayInMinutes: 1, // Start in 1 minute
            periodInMinutes: 7 * 24 * 60 // Repeat every 7 days
        }, () => {
            if (chrome.runtime.lastError) {
                console.error('Error creating weekly alarm:', chrome.runtime.lastError);
                addToWarningMessageList(createWarning('Error setting up weekly backup. Please try again.'));
                return;
            }
            saveSettingsAndUpdateStatus("weekly");
            console.log("Weekly backup schedule set");
        });
    } else {
        // Fallback for web environment
        addToWarningMessageList(createWarning('Automatic scheduling not available in web preview mode.'));
        saveSettingsAndUpdateStatus("weekly");
    }
}

function saveSettingsAndUpdateStatus(schedule) {
    const settings = { autoBackupSchedule: schedule };

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set(settings, () => {
            if (chrome.runtime.lastError) {
                console.error('Error saving settings:', chrome.runtime.lastError);
                return;
            }
            console.log(`Auto-backup schedule saved: ${schedule}`);
            updateStatusText();
        });
    } else {
        // Fallback for web environment
        try {
            localStorage.setItem('autoBackupSchedule', schedule);
            console.log(`Auto-backup schedule saved to localStorage: ${schedule}`);
            updateStatusText();
        } catch (e) {
            console.error('Error saving to localStorage:', e);
        }
    }
}

function updateStatusText() {
    const schedule = scheduleSelect.value;
    const autoTelegram = autoTelegramBackupCheckbox.checked;

    if (schedule === "disabled") {
        statusText.textContent = "Automatic backup is disabled";
    } else {
        let status;
        switch (schedule) {
            case "15min":
                status = "Automatic backup scheduled for every 15 minutes";
                break;
            case "30min":
                status = "Automatic backup scheduled for every 30 minutes";
                break;
            case "hourly":
                status = "Automatic backup scheduled for every hour";
                break;
            case "2hours":
                status = "Automatic backup scheduled for every 2 hours";
                break;
            case "6hours":
                status = "Automatic backup scheduled for every 6 hours";
                break;
            case "12hours":
                status = "Automatic backup scheduled for every 12 hours";
                break;
            case "daily":
                status = "Automatic backup scheduled for every day";
                break;
            case "weekly":
                status = "Automatic backup scheduled for every week";
                break;
            default:
                status = "Automatic backup is configured";
        }
        
        if (autoTelegram) {
            status += " + Telegram";
        }
        statusText.textContent = status;
    }
}