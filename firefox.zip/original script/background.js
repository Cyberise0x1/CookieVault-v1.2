// --- LISTENER FOR SCHEDULED AUTOMATIC BACKUPS ---

// Listen for when the alarm goes off
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "cookieAutoBackup") {
    console.log("Performing automatic cookie backup...");
    performBackup();
  }
});



function performBackup() {
  chrome.cookies.getAll({}, (cookies) => {
    if (cookies.length === 0) {
      console.log("No cookies to backup automatically.");
      return;
    }

    const data = JSON.stringify(cookies, null, 2); // Pretty print JSON
    
    // Create a timestamped filename for the unencrypted backup
    const d = new Date();
    const date = d.toLocaleDateString("en-GB").replace(/\//g, "-");
    const time = d.toLocaleTimeString("en-GB").replace(/:/g, "-");
    const filename = `cookies-auto-backup-${date}-${time}.json`;

    // Use data URL instead of URL.createObjectURL (not available in service workers)
    const dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(data);

    // Download local backup
    chrome.downloads.download({
      url: dataUrl,
      filename: filename
    });
    
    // Also try to send to Telegram if enabled and credentials are available
    sendAutomaticBackupToTelegram(data, filename);
  });
}

// Send automatic backup to Telegram if enabled and credentials are available
async function sendAutomaticBackupToTelegram(cookieData, filename) {
  try {
    // Check if user has enabled automatic Telegram backups
    const settingsResult = await chrome.storage.local.get(["autoTelegramBackup"]);
    const autoTelegramEnabled = settingsResult.autoTelegramBackup;
    
    if (!autoTelegramEnabled) {
      console.log("Automatic Telegram backup is disabled by user");
      return;
    }
    
    // Check if Telegram credentials are stored
    const result = await chrome.storage.local.get(["telegramBotToken"]);
    const credentials = result.telegramBotToken;
    
    if (credentials && credentials.botToken && credentials.chatId) {
      console.log("Sending automatic backup to Telegram...");
      
      // Send to Telegram
      await sendToTelegram(cookieData, credentials.botToken, credentials.chatId, filename);
      console.log("Automatic Telegram backup sent successfully");
    } else {
      console.log("No Telegram credentials found for automatic backup");
    }
  } catch (error) {
    console.error("Error sending automatic backup to Telegram:", error);
    // Don't show user-facing errors for automatic backups
  }
}

// --- LISTENER AND FUNCTIONS FOR TELEGRAM BACKUP ---

// Listen for messages from popup.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "backupToTelegram") {
        console.log("Received request to backup cookies to Telegram.");
        // We make this an async operation to handle the fetch API call
        (async () => {
            try {
                await sendToTelegram(request.data, request.botToken, request.chatId);
                sendResponse({ status: "success", message: "Backup sent to Telegram successfully!" });
            } catch (error) {
                sendResponse({ status: "error", message: error.message });
            }
        })();
        // Return true to indicate you wish to send a response asynchronously
        return true;
    }
});

/**
 * Sends the cookie data as a file to the Telegram Bot API.
 * @param {string} cookieData - The JSON string of the cookies.
 * @param {string} botToken - The Telegram bot token.
 * @param {string} chatId - The Telegram chat ID to send the message to.
 * @param {string} customFilename - Optional custom filename (for automatic backups).
 */
async function sendToTelegram(cookieData, botToken, chatId, customFilename = null) {
    const telegramApiUrl = `https://api.telegram.org/bot${botToken}/sendDocument`;

    // Use custom filename if provided, otherwise create a timestamped one
    let filename;
    if (customFilename) {
        filename = customFilename;
    } else {
        const d = new Date();
        const date = d.toLocaleDateString("en-GB").replace(/\//g, "-");
        const time = d.toLocaleTimeString("en-GB").replace(/:/g, "-");
        filename = `cookies-telegram-backup-${date}-${time}.json`;
    }
    
    // Convert the cookie data string into a Blob to send as a file
    const blob = new Blob([cookieData], { type: 'application/json' });
    
    // Use FormData to structure the multipart/form-data request
    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('document', blob, filename);
    formData.append('caption', `Here is your cookie backup from ${new Date().toLocaleString()}.`);

    const response = await fetch(telegramApiUrl, {
        method: 'POST',
        body: formData // No need to set Content-Type header, fetch does it for FormData
    });

    const result = await response.json();

    if (!result.ok) {
        // If Telegram API returns an error, throw an exception
        throw new Error(`Telegram API Error: ${result.description || 'Unknown error'}`);
    }

    console.log("Successfully sent backup to Telegram:", result);
}